import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
from scipy import stats
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn import preprocessing
from opencage.geocoder import OpenCageGeocode
from IPython.display import FileLink
from sqlalchemy import create_engine
import os
def rename_columns(df):
    df.columns = df.columns.str.lower()
    df.columns = [col.replace(' ', '_') for col in df.columns]

def explore_data(Green_Taxi_To_clean_df):

    Green_Taxi_To_clean_df['pickup_datetime'] = pd.to_datetime(Green_Taxi_To_clean_df['lpep_pickup_datetime'])
    Green_Taxi_To_clean_df['pickup_hour'] = Green_Taxi_To_clean_df['pickup_datetime'].dt.hour
    Green_Taxi_To_clean_df['pickup_day_of_week'] = Green_Taxi_To_clean_df['pickup_datetime'].dt.dayofweek
    
    average_distance_by_hour = Green_Taxi_To_clean_df.groupby('pickup_hour')['trip_distance'].mean()
    average_distance_by_day = Green_Taxi_To_clean_df.groupby('pickup_day_of_week')['trip_distance'].mean()
    average_distance_by_hour,average_distance_by_day
    
    
    # Calculate average trip distance by hour
    average_distance_by_hour = Green_Taxi_To_clean_df.groupby('pickup_hour')['trip_distance'].mean()
    
    # Calculate average trip distance by day of the week
    average_distance_by_day = Green_Taxi_To_clean_df.groupby('pickup_day_of_week')['trip_distance'].mean()
    
    # Plotting average distance by hour
    plt.figure(figsize=(12, 6))
    plt.plot(average_distance_by_hour.index, average_distance_by_hour.values, marker='o')
    plt.xlabel('Hour of the Day')
    plt.ylabel('Average Trip Distance')
    plt.title('Average Trip Distance by Hour of the Day')
    plt.xticks(range(24))
    plt.grid(True)
    plt.show()
    
    # Plotting average distance by day of the week
    plt.figure(figsize=(10, 6))
    plt.plot(average_distance_by_day.index, average_distance_by_day.values, marker='o')
    plt.xlabel('Day of the Week')
    plt.ylabel('Average Trip Distance')
    plt.title('Average Trip Distance by Day of the Week')
    plt.xticks(range(7), ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])
    plt.grid(True)
    plt.show()
    
    average_fare_by_location = Green_Taxi_To_clean_df.groupby('pu_location')['fare_amount'].mean()
    top_locations = average_fare_by_location.nlargest(5)  # Get top 5 locations
    print(top_locations)
    
    average_fare_by_location = Green_Taxi_To_clean_df.groupby('pu_location')['fare_amount'].mean()
    
    # Get top 5 locations with the highest average fare
    top_locations = average_fare_by_location.nlargest(5)
    
    # Plotting top locations by average fare
    plt.figure(figsize=(10, 6))
    sns.barplot(x=top_locations.values, y=top_locations.index)
    plt.xlabel('Average Fare Amount')
    plt.ylabel('Pickup Location')
    plt.title('Top Locations by Average Fare Amount')
    plt.show()
    
    Green_Taxi_To_clean_df['rate_type'].unique()
    
    grouped_data = Green_Taxi_To_clean_df.groupby('rate_type')
    
    rate_info_df = pd.DataFrame(columns=['rate_type', 'pu_locations', 'average_fare_amount'])
    
    for rate_type, rate_group in grouped_data:
        
        pickup_locations = rate_group['pu_location'].unique()# Determine the pickup locations for the rate type
        average_fare = rate_group['fare_amount'].mean()# Calculate the average fare amount for the rate type
        
        
        rate_info_df = rate_info_df.append({'rate_type': rate_type, 'pu_locations': pickup_locations,'average_fare_amount': average_fare},ignore_index=True)
        
        mode_rate_type = rate_info_df['rate_type'].mode().iloc[0]
        print("Mode Rate Type:", mode_rate_type)
        
        # Create a DataFrame to store rate information
        rate_info_df = pd.DataFrame(columns=['rate_type', 'pu_location', 'average_fare_amount'])
        
    for rate_type, rate_group in grouped_data:
        pickup_locations = ', '.join(rate_group['pu_location'].unique())  # Determine the pickup locations for the rate type
        average_fare = rate_group['fare_amount'].mean()  # Calculate the average fare amount for the rate type
        
        rate_info_df = rate_info_df.append({'rate_type': rate_type, 'pu_location': pickup_locations,
                                                'average_fare_amount': average_fare}, ignore_index=True)
            
        # Plotting average fare amount by rate type
    plt.figure(figsize=(10, 6))
    sns.barplot(x='rate_type', y='average_fare_amount', data=rate_info_df)
    plt.xlabel('Rate Type')
    plt.ylabel('Average Fare Amount')
    plt.title('Average Fare Amount by Rate Type')
    plt.show()
    
    Green_Taxi_To_clean_df['pickup_datetime'] = pd.to_datetime(Green_Taxi_To_clean_df['lpep_pickup_datetime'])
    
    Green_Taxi_To_clean_df['pickup_hour'] = Green_Taxi_To_clean_df['pickup_datetime'].dt.hour
    
    hourly_trip_counts = Green_Taxi_To_clean_df['pickup_hour'].value_counts()
    
    rush_hour = Green_Taxi_To_clean_df['pickup_hour'].value_counts().idxmax()
    rush_hour_data = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['pickup_hour'] == rush_hour]
    
    start_time = rush_hour 
    if (start_time > 12):
        start_time = start_time-12
        
    end_time = rush_hour + 1 
    if (end_time > 12):
        end_time = end_time-12
     
    hot_areas = rush_hour_data['pu_location'].value_counts().nlargest(5)
                    
    print("Hot areas during the rush hour:")
    print(hot_areas)
    print("The rush hour is typically between", start_time, "and", end_time)
    
    
    hourly_trip_counts  = Green_Taxi_To_clean_df['pickup_hour'].value_counts()
    
    # Identify rush hour (hour with the highest trip count)
    rush_hour = hourly_trip_counts.idxmax()
    
    # Filter data for rush hour
    rush_hour_data = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['pickup_hour'] == rush_hour]
    
    # Get the start and end times for rush hour
    start_time = rush_hour if rush_hour <= 12 else rush_hour - 12
    end_time = start_time + 1 if start_time < 12 else 1
    
    # Calculate the top 5 hot areas during rush hour
    hot_areas = rush_hour_data['pu_location'].value_counts().nlargest(5)
    
    # Plotting hot areas during rush hour
    plt.figure(figsize=(10, 6))
    sns.barplot(x=hot_areas.values, y=hot_areas.index)
    plt.xlabel('Number of Trips')
    plt.ylabel('Pickup Location')
    plt.title('Hot Areas during Rush Hour')
    plt.show()
    
    passenger_distance_relationship = Green_Taxi_To_clean_df.groupby(['passenger_count', 'rate_type'])['trip_distance'].mean()
    passenger_distance_relationship
    
           # Group data by passenger count and rate type, calculate average trip distance
    passenger_distance_relationship = Green_Taxi_To_clean_df.groupby(['passenger_count', 'rate_type'])['trip_distance'].mean().reset_index()
            
            # Plotting passenger count vs. trip distance
    plt.figure(figsize=(10, 6))
    sns.pointplot(x='passenger_count', y='trip_distance', hue='rate_type', data=passenger_distance_relationship)
    plt.xlabel('Passenger Count')
    plt.ylabel('Average Trip Distance')
    plt.title('Relationship between Passenger Count and Trip Distance (by Rate Type)')
    plt.show()

                  
    average_duration = Green_Taxi_To_clean_df['duration_seconds'].mean()
    highest_duration = Green_Taxi_To_clean_df['duration_seconds'].max()
    
    average_duration_per_day = Green_Taxi_To_clean_df.groupby('pickup_day_of_week')['duration_seconds'].mean()
    average_duration_per_day.plot(kind='bar', figsize=(8, 6))
    plt.xlabel('Day of the Week')
    plt.ylabel('Average Duration (seconds)')
    plt.title('Average Duration per Day of the Week')
    plt.xticks(rotation=0)
    plt.show()
    
    average_fare_by_distance_rate = Green_Taxi_To_clean_df.groupby(['trip_distance', 'rate_type'])['fare_amount'].mean().reset_index()
    plt.figure(figsize=(12, 6))
    sns.scatterplot(x='trip_distance', y='fare_amount', hue='rate_type', data=average_fare_by_distance_rate)
    plt.xlabel('Trip Distance')
    plt.ylabel('Fare Amount')
    plt.title('Average Fare Amount by Trip Distance and Rate Type')
    plt.show()
            
    plt.figure(figsize=(12, 6))
    sns.boxplot(x='pickup_day_of_week', y='trip_distance', data=Green_Taxi_To_clean_df)
    plt.xlabel('Day of the Week')
    plt.ylabel('Trip Distance')
    plt.title('Distribution of Trip Distances by Day of the Week')
    plt.xticks(range(7), ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])
    plt.show()


    average_fare_by_location_payment = Green_Taxi_To_clean_df.groupby(['pu_location', 'payment_type'])['fare_amount'].mean().reset_index()
    top_10_highest_fare = average_fare_by_location_payment.nlargest(20, 'fare_amount')
    plt.figure(figsize=(12, 8))
    sns.barplot(x='pu_location', y='fare_amount', hue='payment_type', data=top_10_highest_fare)
    plt.xlabel('Pickup Location')
    plt.ylabel('Average Fare Amount')
    plt.title('Average Fare Amount by Pickup Location and Payment Type')
    plt.xticks(rotation=90)
    plt.legend(title='Payment Type')
    plt.show()
    
    plt.figure(figsize=(12, 6))
    sns.lineplot(x='pickup_hour', y='trip_distance', hue='passenger_count', data=Green_Taxi_To_clean_df)
    plt.xlabel('Hour of the Day')
    plt.ylabel('Trip Distance')
    plt.title('Trip Distance Variation by Hour of the Day (by Passenger Count)')
    plt.xticks(range(24))
    plt.show()
    
    correlation_data = Green_Taxi_To_clean_df[['trip_distance', 'fare_amount', 'duration']]
    correlation_matrix = correlation_data.corr()
    plt.figure(figsize=(8, 6))
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm')
    plt.title('Correlation Matrix: Trip Distance, Fare Amount, and Duration')
    plt.show()
    graphs = [plt.figure() for _ in range(12)]  # Placeholder for 12 graphs
    return graphs

def calculate_duration(row):
    pickup_time = datetime.strptime(row['lpep_pickup_datetime'], '%Y-%m-%d %H:%M:%S')
    dropoff_time = datetime.strptime(row['lpep_dropoff_datetime'], '%Y-%m-%d %H:%M:%S')
    duration = dropoff_time - pickup_time
    duration_str = str(duration).split(", ")[-1]
    return duration_str

def convert_duration_to_seconds(df, duration_column):
    # Split duration into hours, minutes, and seconds
    df[duration_column] = pd.to_datetime(df[duration_column])
    hours = df[duration_column].dt.hour
    minutes = df[duration_column].dt.minute
    seconds = df[duration_column].dt.second
    duration_seconds = (hours * 3600) + (minutes * 60) + seconds
    df['duration_seconds'] = duration_seconds
    
def pick_hour(Green_Taxi_To_clean_df):
    Green_Taxi_To_clean_df['pickup_datetime'] = pd.to_datetime(Green_Taxi_To_clean_df['lpep_pickup_datetime'])
    Green_Taxi_To_clean_df['pickup_hour_pu'] = Green_Taxi_To_clean_df['pickup_datetime'].dt.hour
    Green_Taxi_To_clean_df['dropoff_datetime'] = pd.to_datetime(Green_Taxi_To_clean_df['lpep_dropoff_datetime'])
    Green_Taxi_To_clean_df['pickup_hour_do'] = Green_Taxi_To_clean_df['dropoff_datetime'].dt.hour 
    
def absoluate(Green_Taxi_To_clean_df):
     columns_to_abs = ['fare_amount', 'extra', 'mta_tax', 'tip_amount', 'improvement_surcharge', 'total_amount']
     for column in columns_to_abs:
         Green_Taxi_To_clean_df[column] = Green_Taxi_To_clean_df[column].abs()
         
def clean_and_process_data(Green_Taxi_To_clean_df):
   
    Green_Taxi_To_clean = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['extra'] <= 1]
    Green_Taxi_To_clean_df.drop('congestion_surcharge', axis=1, inplace=True)
    Green_Taxi_To_clean_df.drop('ehail_fee', axis=1, inplace=True)
    
    Group_ride = Green_Taxi_To_clean_df[(Green_Taxi_To_clean_df['rate_type'] == "Group ride") & (Green_Taxi_To_clean_df['passenger_count'] == 1)]
    Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop(Group_ride.index)

   
    irrelevent_ride = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['passenger_count'] == 333]
    Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop(irrelevent_ride.index)

    
    Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop_duplicates()

    
    Unknown_po = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['pu_location'] == 'Unknown,Unknown']
    indices_to_delete = Unknown_po.index
    Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop(indices_to_delete)

    Unknown_do = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['do_location'] == 'Unknown,Unknown']
    indices_to_delete = Unknown_do.index
    Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop(indices_to_delete)

    Unknown = Unknown_po[Unknown_po['do_location'] == 'Unknown,Unknown']
    indices_to_delete = Unknown.index
    #Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop(indices_to_delete)

    
    duration_cond = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['duration_seconds'] == 0]
    trip_distance_cond = duration_cond[duration_cond['trip_distance'] == 0]
    Green_Taxi_To_clean_df = Green_Taxi_To_clean_df.drop(trip_distance_cond.index)

    
    pass_missing_4 = Green_Taxi_To_clean_df[Green_Taxi_To_clean_df['payment_type'].isnull() == True]
    pass_missing_5 = pass_missing_4[pass_missing_4['tip_amount'] > 0]
    pass_missing_6 = pass_missing_4[pass_missing_4['tip_amount'] == 0.00]
    pass_missing_5['payment_type'] = pass_missing_5['payment_type'].fillna("Credit card")
    Green_Taxi_To_clean_df.update(pass_missing_5['payment_type'])
    Green_Taxi_To_clean_df.update(pass_missing_6['payment_type'])
    Green_Taxi_To_clean_df['payment_type'].fillna("Unknown", inplace=True)

    
    df_1 = Green_Taxi_To_clean_df.copy()
    df_2 = Green_Taxi_To_clean_df.copy()

    rush_hour_start = 16
    rush_hour_end = 20
    rush_hour_charge = 1.0

    
    df_1['extra'] = df_1.apply(lambda row: rush_hour_charge 
                               if rush_hour_start <= row['pickup_hour_pu'] <= rush_hour_end
                              else 0.5 if pd.isna(row['extra']) else row['extra'], axis=1)

    
    average_extra_per_hour = df_2.groupby('pickup_hour_pu')['extra'].mean()
    df_2['extra'] = df_2['extra'].fillna(df_2['pickup_hour_pu'].map(average_extra_per_hour))
    Green_Taxi_To_clean_df.update(df_2['extra'])

    return Green_Taxi_To_clean_df

def visualize_distribution_and_skewness(Green_Taxi_To_missing):
    # Visualizing distribution using kernel density plots
    sns.kdeplot(Green_Taxi_To_missing['fare_amount'])
    plt.title('Distribution of Fare Amount')
    plt.show()

    sns.kdeplot(Green_Taxi_To_missing['passenger_count'])
    plt.title('Distribution of Passenger Count')
    plt.show()

    sns.kdeplot(Green_Taxi_To_missing['extra'])
    plt.title('Distribution of Extra')
    plt.show()

    sns.kdeplot(Green_Taxi_To_missing['tip_amount'])
    plt.title('Distribution of Tip Amount')
    plt.show()

    sns.kdeplot(Green_Taxi_To_missing['tolls_amount'])
    plt.title('Distribution of Tolls Amount')
    plt.show()

    sns.kdeplot(Green_Taxi_To_missing['total_amount'])
    plt.title('Distribution of Total Amount')
    plt.show()

    sns.kdeplot(Green_Taxi_To_missing['trip_distance'])
    plt.title('Distribution of Trip Distance')
    plt.show()

    # Printing skewness
    print('Skewness of Passenger Count:', Green_Taxi_To_missing['passenger_count'].skew())
    print('Skewness of Trip Distance:', Green_Taxi_To_missing['trip_distance'].skew())
    print('Skewness of Fare Amount:', Green_Taxi_To_missing['fare_amount'].skew())
    print('Skewness of Extra:', Green_Taxi_To_missing['extra'].skew())
    print('Skewness of Tip Amount:', Green_Taxi_To_missing['tip_amount'].skew())
    print('Skewness of Tolls Amount:', Green_Taxi_To_missing['tolls_amount'].skew())
    print('Skewness of Total Amount:', Green_Taxi_To_missing['total_amount'].skew())
    
def impute_outliers(df):
    Taxi_imp = df.copy()

    # Impute outliers for passenger_count
    floor = df['passenger_count'].quantile(0.10)
    cap = df['passenger_count'].quantile(0.94)
    Taxi_imp['passenger_count'] = np.where(Taxi_imp['passenger_count'] < floor, floor, Taxi_imp['passenger_count'])
    Taxi_imp['passenger_count'] = np.where(Taxi_imp['passenger_count'] > cap, cap, Taxi_imp['passenger_count'])
    # Impute outliers for trip_distance
    floor = df['trip_distance'].quantile(0.27)
    cap = df['trip_distance'].quantile(0.99)
    Taxi_imp['trip_distance'] = np.where(Taxi_imp['trip_distance'] < floor, floor, Taxi_imp['trip_distance'])
    Taxi_imp['trip_distance'] = np.where(Taxi_imp['trip_distance'] > cap, cap, Taxi_imp['trip_distance'])

    # Impute outliers for fare_amount
    floor = df['fare_amount'].quantile(0.01)
    cap = df['fare_amount'].quantile(0.99)
    Taxi_imp['fare_amount'] = np.where(Taxi_imp['fare_amount'] < floor, floor, Taxi_imp['fare_amount'])
    Taxi_imp['fare_amount'] = np.where(Taxi_imp['fare_amount'] > cap, cap, Taxi_imp['fare_amount'])

    # Impute outliers for extra
    floor = df['extra'].quantile(0.10)
    cap = df['extra'].quantile(0.99)
    Taxi_imp['extra'] = np.where(Taxi_imp['extra'] < floor, floor, Taxi_imp['extra'])
    Taxi_imp['extra'] = np.where(Taxi_imp['extra'] > cap, cap, Taxi_imp['extra'])

    # Impute outliers for tip_amount
    floor = df['tip_amount'].quantile(0.00)
    cap = df['tip_amount'].quantile(1.00)
    Taxi_imp['tip_amount'] = np.where(Taxi_imp['tip_amount'] < floor, floor, Taxi_imp['tip_amount'])
    Taxi_imp['tip_amount'] = np.where(Taxi_imp['tip_amount'] > cap, cap, Taxi_imp['tip_amount'])

        # Impute outliers for tolls_amount
    floor = df['tolls_amount'].quantile(0.10)
    cap = df['tolls_amount'].quantile(0.99)
    Taxi_imp['tolls_amount'] = np.where(Taxi_imp['tolls_amount'] < floor, floor, Taxi_imp['tolls_amount'])
    Taxi_imp['tolls_amount'] = np.where(Taxi_imp['tolls_amount'] > cap, cap, Taxi_imp['tolls_amount'])

        # Impute outliers for total_amount
    floor = df['total_amount'].quantile(0.01)
    cap = df['total_amount'].quantile(0.99)
    Taxi_imp['total_amount'] = np.where(Taxi_imp['total_amount'] < floor, floor, Taxi_imp['total_amount'])
    Taxi_imp['total_amount'] = np.where(Taxi_imp['total_amount'] > cap, cap, Taxi_imp['total_amount'])
    return Taxi_imp

def disc_weeks(df, col, nbins, min_, max_, new_col):
    width = int((max_ - min_) / nbins)
    bins = list(range(min_, max_ + 1, width))
    labels = [str(i) for i in range(1, len(bins))]
    df[new_col] = pd.cut(x=df[col].dt.day, bins=bins, labels=labels, include_lowest=True)
    df[new_col + '_disc'] = pd.cut(x=df[col].dt.day, bins=bins, include_lowest=True)

def process_green_taxi_data(df):
    
  # Convert datetime columns to datetime objects
    df.loc[:, 'lpep_dropoff_datetime'] = pd.to_datetime(df.loc[:, 'lpep_dropoff_datetime'])
    df['lpep_pickup_datetime'] = pd.to_datetime(df['lpep_pickup_datetime'])

    # Discretize weeks using the disc_weeks function
    disc_weeks(df, 'lpep_pickup_datetime', 5, 1, 31, 'week_num')

    return df


def label_encode_columns(df, columns_to_encode):
    result_df = df.copy()
    lookup_table_df = pd.DataFrame(columns=['Column name', 'Original value', 'Imputed Value'])

    for column in columns_to_encode:
        le = preprocessing.LabelEncoder()
        result_df[column] = le.fit_transform(result_df[column])
        lookup_table = dict(zip(le.classes_, le.transform(le.classes_)))

        lookup_table_df = lookup_table_df._append(pd.DataFrame([(column, original_value, imputed_value) 
            for original_value, imputed_value in lookup_table.items()],
                columns=['Column name', 'Original value', 'Imputed Value']),
                ignore_index=True)

    return result_df, lookup_table_df

def weekend(df,col,newcol):
    df.loc[df[col].dt.weekday.isin([4,5,6]),newcol] = True 
    df.loc[df[col].dt.weekday.isin([0,1,2,3,]),newcol] = False
    
def geocode_and_merge(df, pickup_column, dropoff_column, api_key):
    def geocode_location(location):
        geocoder = OpenCageGeocode(api_key)
        results = geocoder.geocode(location)
        if len(results) > 0:
            lat = results[0]['geometry']['lat']
            lng = results[0]['geometry']['lng']
            return lat, lng
        else:
            return None, None

    pickup_locations = df[pickup_column].unique()
    dropoff_locations = df[dropoff_column].unique()

    geocoded_data = []
    for location in set(pickup_locations) | set(dropoff_locations):
        lat, lng = geocode_location(location)
        geocoded_data.append({'location': location, 'latitude': lat, 'longitude': lng})

    geocoded_df = pd.DataFrame(geocoded_data)
    df_geocode = df.copy()

    missing_geocoded_df = geocoded_df.loc[geocoded_df.latitude.isnull()]

    missing_geocoded = []
    for location in set(missing_geocoded_df.location):
        location_parts = location.split(',')[0]
        lat, lng = geocode_location(location_parts)
        missing_geocoded.append({'location': location, 'latitude': lat, 'longitude': lng})

    missing_geocoded_df2 = pd.DataFrame(missing_geocoded)
    geocoded_df.update(missing_geocoded_df2)

    merged_df_pickup = pd.merge(df_geocode, geocoded_df, left_on=pickup_column, right_on='location', how='left')
    df_geocode['pickup_latitude'] = merged_df_pickup['latitude']
    df_geocode['pickup_longitude'] = merged_df_pickup['longitude']

    merged_df_dropoff = pd.merge(df_geocode, geocoded_df, left_on=dropoff_column, right_on='location', how='left')
    df_geocode['dropoff_latitude'] = merged_df_dropoff['latitude']
    df_geocode['dropoff_longitude'] = merged_df_dropoff['longitude']

    df_geocode.to_csv('dataset_with_coordinates.csv', index=False)
    return df_geocode

def establish_connection(db_name):
	
	engine = create_engine(f'postgresql://root:root@pgdatabase:5432/{db_name}')

	engine.connect()
	# return engine(connection cursor)
	return engine

# example func. you might use in the milestone
def check_clean_csv(file_to_check):
	if os.path.exists(file_to_check):
		return True
	return False

def upload_csv(filename,table_name,engine):  
	df = pd.read_csv(filename)
	try:
		df.to_sql(table_name, con = engine, if_exists='fail', index=False)
		print('csv file uploaded to the db as a table')
	except ValueError as e:
		print("Table already exists. Error:", e)

