import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
from scipy import stats
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn import preprocessing
from opencage.geocoder import OpenCageGeocode
from IPython.display import FileLink
from Functions import *
import warnings
warnings.filterwarnings("ignore")
if (os.path.exists('../data/green_trip_data_17-8_clean.csv')):
    print('Data is already cleaned it will now be uploaded')
    engine=establish_connection('green_taxi_8_17_postgres')
    upload_csv('/data/green_trip_data_17-8_clean.csv', 'green_tripdata_17-8' , engine)  
else: 
    data_dir = '../data/'
    Green_Taxi_df = pd.read_csv(data_dir + 'green_tripdata_17-8.csv')
    df = Green_Taxi_df
    #Look_up_table = pd.read_csv(data_dir + 'lookup_green_taxi_17-8-8.csv')
    #Functions

    rename_columns(Green_Taxi_df)    
    Green_Taxi_df['duration'] = Green_Taxi_df.apply(calculate_duration, axis=1)     
    convert_duration_to_seconds(Green_Taxi_df, 'duration')
    pick_hour(Green_Taxi_df) 
    #Green_Taxi_df = explore_data(Green_Taxi_df)
    absoluate(Green_Taxi_df)
    print('Part 1 done')
    Green_Taxi_df = clean_and_process_data(Green_Taxi_df)
    #visualize_distribution_and_skewness(Green_Taxi_df)
    Green_Taxi_To_missing = impute_outliers(Green_Taxi_df)
    Green_Taxi_To_missing = process_green_taxi_data(Green_Taxi_To_missing)
    print('Part 2 done')
    columns_to_encode = ['vendor', 'store_and_fwd_flag', 'rate_type', 'pu_location', 'do_location', 'payment_type', 'trip_type']
    encoded_df, lookup_table_df = label_encode_columns(Green_Taxi_To_missing, columns_to_encode)
    
    weekend(encoded_df,'lpep_pickup_datetime','weekend')    
    weekend(Green_Taxi_To_missing,'lpep_pickup_datetime','weekend')
    print('Part 3 done')
    
    #API_KEY = '5d18223b271c453db5f0dd4235e29692'  # Replace with your actual API key
    #Green_Taxi_geocoded = geocode_and_merge(Green_Taxi_To_missing, 'pu_location', 'do_location', API_KEY)
      
    # Save the DataFrame as a CSV file
    print('Data cleaned and ready to upload')
    lookup_table_df.to_csv(data_dir + "lookup_green_taxi_17-8.csv", index=False)        
    Green_Taxi_To_missing.to_csv(data_dir + "green_trip_data_17-8_clean.csv", index=False)        
    encoded_df.to_csv(data_dir + "green_trip_data_17-8_encoded.csv", index=False) 
    Green_Taxi_To_missing.to_csv(data_dir + "green_trip_data_17-8_clean.csv", index=False)

    engine=establish_connection('green_taxi_8_17_postgres')
    upload_csv('/data/green_trip_data_17-8_clean.csv', 'green_tripdata_17-8' , engine)
    upload_csv('/data/lookup_green_taxi_17-8.csv', 'lookup_green_taxi_17-8' , engine) 
    print('Data is Uploaded')

